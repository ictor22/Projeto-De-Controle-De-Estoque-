/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.dao;

import model.Produto;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import util.ConectaDB;
/**
 *
 * @author alunocmc
 */
public class ProdutoDAO {
   //Atributos
    // Sem atributos
    
    public boolean insProd(Produto p_prod) throws ClassNotFoundException {
    // Conectar ao banco de dados
    Connection conexao = null;
    try {
        conexao = ConectaDB.conectar(); // Abre a conexão com o banco de dados

        // Prepara a consulta SQL
        Statement stmt = conexao.createStatement();

        // Certifique-se de que os valores de categoria estão entre aspas
        String sql = "INSERT INTO armazem (registro, nome_produto, modelo, categoria) " + 
                     "VALUES ('" + p_prod.getRegistro() + "', '" + 
                     p_prod.getNome_produto() + "', '" + 
                     p_prod.getModelo() + "', '" + 
                     p_prod.getCategoria() + "')";

        // Executa o comando SQL de inserção
        stmt.executeUpdate(sql); // Executa o SQL (INSERT)

        // Fecha a conexão
        conexao.close();
        
        // Retorna verdadeiro se a inserção for bem-sucedida
        return true;
    } catch (SQLException ex) {
        // Imprime qualquer erro ocorrido no SQL
        System.out.println("Exception: " + ex.toString());
        
        // Retorna falso em caso de erro
        return false;
    }
}

    
    public List consProdLista() throws ClassNotFoundException{
    //Connectar
        List lista = new ArrayList(); // Minha Lista
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();                                   
                        
            String sql = "SELECT * from armazem";
            ResultSet rs = stmt.executeQuery(sql); //GO - Executar - Select
            
            int n_reg = 0;
            while (rs.next()) {                 
                Produto produto = new Produto();  
                produto.setRegistro(Integer.parseInt(rs.getString("registro")));  
                produto.setNome_produto(rs.getString("nome_produto"));                
                produto.setModelo (rs.getString("modelo"));                               
                produto.setCategoria(rs.getString("categoria")); 
                lista.add(produto);
                n_reg++;
            }
            conexao.close();
            
            if (n_reg==0){
                return null;
            }else{
                return lista;
            }
        }catch(SQLException ex){
            System.out.println("Erro:" + ex);
            return null;
        }
    }
    
    public Produto consProdRegIdent(Produto produto) throws ClassNotFoundException{
    //Connectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();                                   
                        
            String sql = "SELECT * from armazem where registro = '" + produto.getRegistro()+ "'";
            ResultSet rs = stmt.executeQuery(sql); //GO - Executar - Select
            
            int n_reg = 0;
            while (rs.next()) {                   
                produto.setRegistro(Integer.parseInt(rs.getString("registro"))); 
                produto.setNome_produto(rs.getString("Nome_produto"));                
                produto.setModelo(rs.getString("modelo"));                
                produto.setCategoria(rs.getString("categoria"));  
                n_reg++;
            }
            conexao.close();
            
            if (n_reg==0){
                return null;
            }else{
                return produto;
            }
        }catch(SQLException ex){
            System.out.println("Erro:" + ex);
            return null;
        }
    }
    
    public boolean exPesqId(Produto produto) throws ClassNotFoundException{
    //Connectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); // Abre a conexão
            Statement stmt = conexao.createStatement();                                   
                        
            String sql = "DELETE from armazem where registro = " + produto.getRegistro();
            stmt.executeUpdate(sql);            
            conexao.close();            
            return true;
            
        }catch(SQLException ex){
            System.out.println("Erro:" + ex);
            return false;
        }
    }
    
    public boolean altProd(Produto p_prod) throws ClassNotFoundException {
    // Conectar ao banco de dados
    Connection conexao = null;
    PreparedStatement stmt = null;
    try {
        conexao = ConectaDB.conectar(); // Abre a conexão
        
        // Defina a consulta SQL para atualizar os dados
        String sql = "UPDATE armazem SET nome_produto = ?, modelo = ?, categoria = ? WHERE registro = ?";
        
        // Prepare a declaração SQL
        stmt = conexao.prepareStatement(sql);
        
        // Atribua os valores aos parâmetros da consulta SQL
        stmt.setString(1, p_prod.getNome_produto());    // Nome do produto
        stmt.setString(2, p_prod.getModelo());           // Modelo
        stmt.setString(3, p_prod.getCategoria());       // Categoria (Verifique se a categoria é String ou outro tipo)
        stmt.setInt(4, p_prod.getRegistro());           // Registro (A chave primária)
        
        // Execute a atualização no banco de dados
        int rowsAffected = stmt.executeUpdate();
        
        // Se pelo menos uma linha for afetada, a atualização foi bem-sucedida
        return rowsAffected > 0;
        
    } catch (SQLException ex) {
        System.out.println("Erro ao atualizar produto: " + ex.toString());
        return false;
    } finally {
        // Fechar recursos de banco de dados
        try {
            if (stmt != null) {
                stmt.close();
            }
            if (conexao != null) {
                conexao.close();
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fechar recursos: " + e.getMessage());
        }
    }
}
}


