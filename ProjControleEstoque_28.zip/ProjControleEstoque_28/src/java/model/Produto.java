/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author rique
 */
public class Produto {
    //atrib
    private int id;
    private int registro;
    private String nome_produto;
    private String modelo;
    private String categoria;
    
    //metod

    public int getId() {
        return id;
    }

    public int getRegistro() {
        return registro;
    }

    public String getNome_produto() {
        return nome_produto;
    }

    public String getModelo() {
        return modelo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRegistro(int registro) {
        this.registro = registro;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
}
